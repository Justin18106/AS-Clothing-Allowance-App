from tkinter import *
from tkinter import ttk


class Account:
    def __init__(self, name, balance):
        self.name = name
        self.balance = float(balance)
        allowance_list.append(self)

    def deduct(self, amount):
        pass

    def get_bonus(self):
        pass


def get_data():
    allowance_file = open("allowance.txt","r")
    line_list = allowance_file.readlines()

    for line in line_list:
        allowance_data = line.strip().split(",")
        Account(*allowance_data)

    allowance_file.close()


def create_name_list():
    name_list = []
    for data in allowance_list:
        name_list.append(data.name)
    return name_list


allowance_list = []

get_data()
childrens_names = create_name_list()

root = Tk()
root.title("Clothing Allowance")

top_frame = ttk.LabelFrame(root, text="Allowance Details")
top_frame.grid(row=0, column=0, padx=10, pady=10, sticky="NSEW")

message_text = StringVar()
message_text.set("Placeholder text. Placeholder text. Placeholder text. Placeholder text. Placeholder text. Placeholder text.")

message_label = ttk.Label(top_frame, textvariable=message_text, wraplength=250)
message_label.grid(row=0, column=0, columnspan=3, padx=10, pady=10)

allowance_label = ttk.Label(top_frame, text="Allowance")
allowance_label.grid(row=1, column=1, padx=10, pady=3)

bonus_label = ttk.Label(top_frame, text="Bonus")
bonus_label.grid(row=1, column=2, padx=10, pady=3)

childA_label = ttk.Label(top_frame, text=childrens_names[0])
childA_label.grid(row=2, column=0, padx=10, pady=3)

childB_label = ttk.Label(top_frame, text=childrens_names[1])
childB_label.grid(row=3, column=0, padx=10, pady=3)

childC_label = ttk.Label(top_frame, text=childrens_names[2])
childC_label.grid(row=4, column=0, padx=10, pady=3)

bottom_frame = ttk.LabelFrame(root, text="Allowance Deduction")
bottom_frame.grid(row=1, column=0, padx=10, pady=10, sticky="NSEW")

child_label = ttk.Label(bottom_frame, text="Child: ")
child_label.grid(row=5, column=0, padx=10, pady=3)

chosen_account = StringVar()
chosen_account.set(childrens_names[0])

child_box = ttk.Combobox(bottom_frame, textvariable=chosen_account, state="readonly")
child_box['values'] = childrens_names
child_box.grid(row=5, column=1, padx=10, pady=3, sticky="WE")

amount_label = ttk.Label(bottom_frame, text="Amount:")
amount_label.grid(row=6, column=0, padx=10, pady=3)

amount = DoubleVar()
amount.set("")

amount_entry = ttk.Entry(bottom_frame, textvariable=amount)
amount_entry.grid(row=6, column=1, padx=10, pady=3, sticky="WE")

enter_button = ttk.Button(bottom_frame, text="Enter") # command
enter_button.grid(row=7, column=0, columnspan=2, padx=10, pady=10)

action_feedback = StringVar()
action_feedback.set("Feedback Message")
action_feedback_label = ttk.Label(bottom_frame, textvariable=action_feedback)
action_feedback_label.grid(row=8, column=0, columnspan=2, pady=10)


root.mainloop()
