from tkinter import *
from tkinter import ttk


# Create Allowance class
class Allowance:
    def __init__(self, name, balance):
        self.name = name
        self.balance = float(balance)
        allowance_list.append(self)

    
    # deduct money from balance
    def deduct(self, amount):
        if amount <= self.balance and amount > 0:
            self.balance -= amount
            return True
        else:
            return False


 # Function to read data from file
def get_data():
    allowance_file = open("allowance.txt", "r")
    line_list = allowance_file.readlines()

    for line in line_list:
        allowance_data = line.strip().split(",")
        Allowance(*allowance_data)

    allowance_file.close()


 # Function to create list of names
def create_name_list():
    name_list = []
    for data in allowance_list:
        name_list.append(data.name)
    return name_list


 # Function to create list of balances
def bal_list():
    bal_list = []
    for data in allowance_list:
        bal_list.append(data.balance)
    return bal_list


 # Function to calculate bonus eligibility and creates file
def get_bonus():
    bonus_list = []
    requirement = 50
    for data in allowance_list:
        if data.balance > requirement:
            bonus_list.append("Available")
        else:
            bonus_list.append("Unavailable")
    return bonus_list


 # Function to update balances and bonus eligibility
def update():
    allowance_file = open("allowance.txt", "w")
    
    for data in allowance_list:
        allowance_file.write("{}, {}\n".format(data.name, data.balance))
    
    # Updates balances and bonuses    
    balance = bal_list()
    balanceA.set(balance[0])
    balanceB.set(balance[1])
    balanceC.set(balance[2])
    bonus = get_bonus()
    bonusA.set(bonus[0])
    bonusB.set(bonus[1])
    bonusC.set(bonus[2])
    allowance_file.close()


# Create a deduction function
def deduct_money(data):
    if data.deduct(amount.get()):
        action_feedback.set("${:.2f} has been deducted from {}'s account.".format(amount.get(), data.name))
    else:
        action_feedback.set("Error")


# Create an action function
def action():
    try:
        for data in allowance_list:
            if chosen_account.get() == data.name:
                deduct_money(data)
        
        # Updates the GUI        
        update()
        amount.set("")
    
    # Exeption for text input    
    except:
        action_feedback.set("Please enter a valid number")


# Setup list
allowance_list = []

# Creates instances of class
get_data()
childrens_names = create_name_list()
balance = bal_list()
bonus = get_bonus()

root = Tk()
root.title("Clothing Allowance")

# Create the top frame
top_frame = ttk.LabelFrame(root, text="Allowance Details")
top_frame.grid(row=0, column=0, padx=10, pady=10, sticky="NSEW")

# Create the message text variable
message_text = StringVar()
message_text.set("Welcome! This app allows you to select a child and deducted money from their account. ")

# Create and pack message label
message_label = ttk.Label(top_frame, textvariable=message_text, wraplength=250)
message_label.grid(row=0, column=0, columnspan=3, padx=10, pady=10)

# Create a label for allowances
allowance_label = ttk.Label(top_frame, text="Allowance")
allowance_label.grid(row=1, column=1, padx=10, pady=3)

# Create a label for bonuses
bonus_label = ttk.Label(top_frame, text="Bonus")
bonus_label.grid(row=1, column=2, padx=10, pady=3)

# Create a label for childA (Nikau)
childA_label = ttk.Label(top_frame, text=childrens_names[0])
childA_label.grid(row=2, column=0, padx=10, pady=3)

# Create and set string variable for balanceA
balanceA = StringVar()
balanceA.set(balance[0])  

# Create a label for balanceA
balanceA_label = ttk.Label(top_frame, textvariable=balanceA)
balanceA_label.grid(row=2, column=1, padx=10, pady=3)

# Create and set string variable for BonusA
bonusA = StringVar()
bonusA.set(bonus[0])

# Create a label for bonusA
bonusA_label = ttk.Label(top_frame, textvariable=bonusA)
bonusA_label.grid(row=2, column=2, padx=10, pady=3)

childB_label = ttk.Label(top_frame, text=childrens_names[1])
childB_label.grid(row=3, column=0, padx=10, pady=3)

balanceB = StringVar()
balanceB.set(balance[1])

balanceB_label = ttk.Label(top_frame, textvariable=balanceB)
balanceB_label.grid(row=3, column=1, padx=10, pady=3)

bonusB = StringVar()
bonusB.set(bonus[1])

bonusB_label = ttk.Label(top_frame, textvariable=bonusB)
bonusB_label.grid(row=3, column=2, padx=10, pady=3)

childC_label = ttk.Label(top_frame, text=childrens_names[2])
childC_label.grid(row=4, column=0, padx=10, pady=3)

balanceC = StringVar()
balanceC.set(balance[2])  

balanceC_label = ttk.Label(top_frame, textvariable=balanceC)
balanceC_label.grid(row=4, column=1, padx=10, pady=3)

bonusC = StringVar()
bonusC.set(bonus[2])

bonusC_label = ttk.Label(top_frame, textvariable=bonusC)
bonusC_label.grid(row=4, column=2, padx=10, pady=3)

# Create the bottom frame
bottom_frame = ttk.LabelFrame(root, text="Deduct Allowance")
bottom_frame.grid(row=1, column=0, padx=10, pady=10, sticky="NSEW")

# Create a label for the child combobox
child_label = ttk.Label(bottom_frame, text="Child: ")
child_label.grid(row=5, column=0, padx=10, pady=3)

# Set up a variable and option list for the child Combobox
chosen_account = StringVar()
chosen_account.set(childrens_names[0])

# Create a combobox to select the child
child_box = ttk.Combobox(bottom_frame, textvariable=chosen_account, state="readonly")
child_box['values'] = childrens_names
child_box.grid(row=5, column=1, padx=10, pady=3, sticky="WE")

# Create a label for the amount entry
amount_label = ttk.Label(bottom_frame, text="Amount:")
amount_label.grid(row=6, column=0, padx=10, pady=3)

# Create a variable to store the amount
amount = DoubleVar()
amount.set("")

# Create an entry to type in the amount
amount_entry = ttk.Entry(bottom_frame, textvariable=amount)
amount_entry.grid(row=6, column=1, padx=10, pady=3, sticky="WE")

# Create an enter button
enter_button = ttk.Button(bottom_frame, text="Enter", command=action) # command
enter_button.grid(row=7, column=0, columnspan=2, padx=10, pady=10)

# Create and action feedback label
action_feedback = StringVar()
action_feedback_label = ttk.Label(bottom_frame, textvariable=action_feedback)
action_feedback_label.grid(row=8, column=0, columnspan=2, pady=10)


#run the main loop
root.mainloop()
